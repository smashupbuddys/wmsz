import React from 'react';
import { formatCurrency } from '../lib/billUtils';

interface Customer {
  name: string;
  phone: string;
  state: string;
  address?: string;
  idType: string;
  idNumber: string;
}

interface BillItem {
  description: string;
  hsn: string;
  gstRate: number;
  quantity: number;
  rate: number;
  amount: number;
  cgst?: number;
  sgst?: number;
  igst?: number;
  total: number;
}

interface Bill {
  billNumber: string;
  createdAt: string;
  customerData: string;
  items: string;
  gstType: 'CGST_SGST' | 'IGST';
  amount: number;
  gstAmount: number;
  total: number;
}

interface BillPreviewProps {
  bill: Bill;
  onClose: () => void;
}

const companyInfo = {
  name: 'VM Jewellers',
  address: '5121/A, Ground Floor, Near Hanuman Mandir,',
  location: 'Rui Mandi, Sadar Bazar, Delhi - 110006',
  gstin: '07NDBPS0625E2ZJ',
  phone: '+91 85878 91402',
  email: 'vs5581764@gmail.com'
};

const BillPreview: React.FC<BillPreviewProps> = ({ bill, onClose }) => {
  const customer: Customer = React.useMemo(() => 
    typeof bill.customerData === 'string' ? JSON.parse(bill.customerData) : bill.customerData,
    [bill.customerData]
  );

  const items: BillItem[] = React.useMemo(() => 
    typeof bill.items === 'string' ? JSON.parse(bill.items) : bill.items,
    [bill.items]
  );

  const handlePrint = React.useCallback(() => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow popups for printing');
      return;
    }

    // Import the PrintTemplate component
    const printTemplate = PrintTemplate({ bill, customer, items });
    
    printWindow.document.write(printTemplate);
    printWindow.document.close();
    
    // Wait for images and styles to load
    printWindow.onload = () => {
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 250);
    };
  }, [bill, customer, items]);

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{companyInfo.name}</h2>
              <p className="text-sm text-gray-500">{companyInfo.address}</p>
              <p className="text-sm text-gray-500">{companyInfo.location}</p>
              <p className="text-sm text-gray-500">GSTIN: {companyInfo.gstin}</p>
              <p className="text-sm text-gray-500">Phone: {companyInfo.phone}</p>
            </div>
            <div className="text-right">
              <h3 className="text-lg font-semibold text-gray-900">Invoice #{bill.billNumber}</h3>
              <p className="text-sm text-gray-500">
                Date: {new Date(bill.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>

        {/* Customer Details */}
        <div className="p-6 border-b">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-2">Bill To:</h3>
              <div className="space-y-1">
                <p className="text-sm text-gray-700">{customer.name}</p>
                <p className="text-sm text-gray-500">{customer.phone}</p>
                <p className="text-sm text-gray-500">{customer.state}</p>
                {customer.address && <p className="text-sm text-gray-500">{customer.address}</p>}
                <p className="text-sm text-gray-500">{customer.idType}: {customer.idNumber}</p>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-2">Supply Details:</h3>
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Place of Supply: {customer.state}</p>
                <p className="text-sm text-gray-500">Country of Supply: India</p>
              </div>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="p-6">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sr.No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">HSN/SAC</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GST Rate</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Qty</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rate</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  {bill.gstType === 'CGST_SGST' ? (
                    <>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CGST</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SGST</th>
                    </>
                  ) : (
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IGST</th>
                  )}
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {items.map((item, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{index + 1}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{item.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.hsn}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.gstRate}%</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.quantity}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(item.rate)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(item.amount)}</td>
                    {bill.gstType === 'CGST_SGST' ? (
                      <>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(item.cgst || 0)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(item.sgst || 0)}</td>
                      </>
                    ) : (
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(item.igst || 0)}</td>
                    )}
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{formatCurrency(item.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Totals */}
        <div className="p-6 border-t bg-gray-50">
          <div className="flex justify-end">
            <div className="w-72">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Subtotal:</span>
                  <span className="text-sm text-gray-900">{formatCurrency(bill.amount)}</span>
                </div>
                {bill.gstType === 'CGST_SGST' ? (
                  <>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">CGST (1.5%):</span>
                      <span className="text-sm text-gray-900">{formatCurrency(bill.gstAmount / 2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">SGST (1.5%):</span>
                      <span className="text-sm text-gray-900">{formatCurrency(bill.gstAmount / 2)}</span>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">IGST (3%):</span>
                    <span className="text-sm text-gray-900">{formatCurrency(bill.gstAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t">
                  <span className="text-sm font-medium text-gray-900">Total:</span>
                  <span className="text-sm font-medium text-gray-900">{formatCurrency(bill.total)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t">
          <div className="text-center text-sm text-gray-500 mb-4">
            For any enquiry, reach out via email at {companyInfo.email} or call on {companyInfo.phone}
          </div>
          <div className="flex justify-end space-x-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
            >
              Print
            </button>
            <button
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BillPreview;