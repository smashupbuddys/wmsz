import { useState } from 'react';
import { Customer, Bill, BillItem } from '../types';
import { generateItemBreakdown, calculateGST, distributeAmount } from '../utils/billCalculations';
import { db } from '../../../lib/db';

export const useBillGeneration = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateBill = async (
    customer: Customer,
    amount: number,
    options?: {
      isPartOfSplit?: boolean;
      splitIndex?: number;
      totalSplits?: number;
    }
  ): Promise<Bill | null> => {
    setIsGenerating(true);
    setError(null);

    try {
      const items = generateItemBreakdown(amount);
      const itemsWithGST = calculateGST(items, customer.state);
      
      const billNumber = await db.getNextBillNumber();
      const billId = crypto.randomUUID();

      const bill: Bill = {
        id: billId,
        billNumber: `INV${billNumber.toString().padStart(6, '0')}`,
        customer,
        items: itemsWithGST,
        amount: items.reduce((sum, item) => sum + item.amount, 0),
        gstType: customer.state.toLowerCase() === 'delhi' ? 'CGST_SGST' : 'IGST',
        gstAmount: itemsWithGST.reduce((sum, item) => sum + (item.igst || (item.cgst! + item.sgst!)), 0),
        total: amount,
        date: new Date().toISOString(),
        ...options,
        createdAt: new Date().toISOString()
      };

      await db.createBill(bill);
      return bill;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate bill');
      return null;
    } finally {
      setIsGenerating(false);
    }
  };

  return {
    generateBill,
    isGenerating,
    error
  };
};
